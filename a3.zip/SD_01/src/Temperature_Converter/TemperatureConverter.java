package Temperature_Converter;

import java.util.Scanner;

public class TemperatureConverter {

	//METHODS TO CONVERT TEMPERATURE
	public static double celsiusTofahrenheit(double celsius) {
		return (celsius * 9/5) + 32;
	}
	
	public static double celsiusTokelvin(double celsius) {
		return celsius + 273.15;
	}
	
	public static double fahrenheitTocelsius(double fahrenheit) {
		return (fahrenheit - 32) * 5/9;
	}
	
	public static double fahrenheitTokelvin(double fahrenheit) {
		return fahrenheitTocelsius(fahrenheit) + 273.15;
	}
	
	public static double kelvinTocelsius(double kelvin) {
		return kelvin - 273.15;
	}
	
	public static double kelvinTofahrenheit(double kelvin) {
		return celsiusTofahrenheit(kelvinTocelsius(kelvin)) ;
	}
	
	//METHOD TO GET THE USER INPUT
	public static void getUserInput() {
	
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the temperature value : ");
		double temp = scanner.nextDouble();
		
		System.out.println("Enter the unit of temperature (C for Celsius, F for Fahrenheit, K for Kelvin) : ");
		char unit = scanner.next().toUpperCase().charAt(0);
	
		convertTemperature(temp,unit);
	}	
	
	
	//METHOD TO HANDLE CONVERSION BASED ON USER INPUT
	private static void convertTemperature(double temp, char unit) {
		double celsius =0 , fahrenheit = 0, kelvin = 0;
		
		switch(unit) {
		
		case 'C' : 
			celsius = temp;
			fahrenheit = celsiusTofahrenheit(temp);
			kelvin = celsiusTokelvin(temp);
			break;
			
		case 'F' : 
			celsius = fahrenheitTocelsius(temp);
			fahrenheit = temp;
			kelvin = fahrenheitTokelvin(temp);
			break;
			
		case 'K' : 
			celsius = kelvinTocelsius(temp);
			fahrenheit = kelvinTofahrenheit(temp);
			kelvin = temp;
			break;
		default:
			System.out.println("Invalid unit entered. Please enter C, F or K");
		}
		
		displayResults(celsius, fahrenheit, kelvin);
	}

	
	//METHOD TO DISPLAY RESULTS
	private static void displayResults(double celsius, double fahrenheit, double kelvin) {
		
		System.out.println("Temperature in Celsius: " + celsius);
		System.out.println("Temperature in Fahrenheit: " + fahrenheit);
		System.out.println("Temperature in Kelvin: " + kelvin);
		
	}

	public static void main(String args[]) {
		getUserInput();
	}
}
